const step1= [
    123,
    'false',
    null,
    777,
];
for (let index = 0; index < 2; index++)
    {
        console.log(step1[index*2+1]+',  ')
    }